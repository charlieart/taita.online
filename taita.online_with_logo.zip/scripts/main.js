document.addEventListener('DOMContentLoaded', () => {
  const hamburger = document.getElementById('hamburger');
  const nav = document.getElementById('nav-menu');
  const modal = document.getElementById('modal');
  const closeModal = document.getElementById('close-modal');
  const modalBody = document.getElementById('modal-body');
  const searchInput = document.getElementById('search');

  hamburger.addEventListener('click', () => nav.classList.toggle('active'));
  closeModal.addEventListener('click', () => modal.style.display = 'none');

  document.querySelectorAll('.ver-detalle').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.target.dataset.id;
      modalBody.innerHTML = `<h2>Producto ${id}</h2><p>Descripción detallada del producto ${id}.</p>`;
      modal.style.display = 'flex';
    });
  });

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    document.querySelectorAll('.card').forEach(card => {
      const text = card.innerText.toLowerCase();
      card.style.display = text.includes(query) ? 'block' : 'none';
    });
  });
});
