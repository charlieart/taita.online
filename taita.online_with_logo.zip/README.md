# Taita Online — Sitio Manga

Sitio web estático con estética manga/anime, desarrollado con HTML5, CSS3 y JavaScript vanilla.

## 🚀 Características
- Paleta contrastada (blanco, negro y rojo).
- Efectos tipo viñeta y sombra cómic.
- Menú responsive y animaciones suaves.
- Modal de detalle de producto y búsqueda instantánea.
- Listo para GitHub Pages.
